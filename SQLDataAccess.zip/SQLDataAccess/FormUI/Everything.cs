﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Everything
    {
        public int Clubs_ID { get; set; }
        public DateTime date_of_establishment { get; set; }
        public string Clubs_name { get; set; }
        public int Stadium_ID { get; set; }
        public int Owners_ID { get; set; }
        public int Owners_Club_ID { get; set; }
        public int Sponsor_ID { get; set; }
        public string Owners_full_name { get; set; }
        public DateTime Owners_date_of_birth { get; set; }
        public Decimal club_Profit { get; set; }
        public DateTime club_Purchase_Date { get; set; }
        public DateTime club_Sale_Date { get; set; }
        public int Players_ID { get; set; }
        public int Players_Club_ID { get; set; }
        public string Players_Name { get; set; }
        public int age { get; set; }
        public string nationality { get; set; }
        public Decimal Players_wage { get; set; }
        public string position_in_team { get; set; }
        public int number_in_team { get; set; }
        public int weight { get; set; }
        public int height { get; set; }
        public int Sponsors_ID { get; set; }
        public string Sponsors_name { get; set; }
        public string service { get; set; }
        public int Stad_ID { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string city { get; set; }
        public int capacity { get; set; }
        public int ID { get; set; }
        public int Club_ID { get; set; }
        public string full_name { get; set; }
        public DateTime date_of_birth { get; set; }
        public string position { get; set; }
        public Decimal wage { get; set; }
        public DateTime date_of_appointment { get; set; }
        public DateTime dismissal_date { get; set; }


        public string Club_Info
        {
            get
            {
                return $"{ Clubs_ID } { date_of_establishment } { Clubs_name } { Stadium_ID }";
            }
        }
        public string Owner_Info
        {
            get
            {
                return $"{ Owners_ID } { Owners_Club_ID } { Sponsor_ID} { Owners_full_name } { Owners_date_of_birth } { club_Profit } { club_Purchase_Date } { club_Sale_Date }";
            }
        }
        public string Players_Info
        {
            get
            {
                return $"{ Players_ID} { Players_Club_ID } { Players_Name } { age } { nationality } { Players_wage } { position_in_team } { number_in_team } { weight } { height }";
            }
        }
        public string Sponsor_Info
        {
            get
            {
                return $"{ Sponsors_ID } { Sponsors_name } { service }";
            }
        }
        public string Stadium_Info
        {
            get
            {
                return $"{ Stad_ID } { name } { country } { city } { capacity }";
            }
        }
        public string Trainers_Info
        {
            get
            {
                return $"{ ID } { Club_ID } { full_name } { date_of_birth } { position } { wage } { date_of_appointment } { dismissal_date }";
            }
        }
    }
}
