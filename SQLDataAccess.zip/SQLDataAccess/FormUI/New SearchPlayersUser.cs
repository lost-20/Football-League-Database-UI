﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class NewSPUser: Form
    {
        string connectionString = @"Server=W12-418-29;DataBase=Football_League;Trusted_Connection=True";
        List<Players> pl = new List<Players>();
        public NewSPUser()
        {
            InitializeComponent();
            modificationButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            modificationButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            reportButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            reportButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            viewButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            viewButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            PopulateComboBoxN();
            PopulateComboBoxPp();
        }


        private void logoPanel_Paint(object sender, PaintEventArgs e)
        {
            logoPanel.BackColor = Color.FromArgb(229, 126, 49);
        }

        private void sidePanel_Paint(object sender, PaintEventArgs e)
        {
            sidePanel.BackColor = Color.FromArgb(41, 53, 65);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn log = new LogIn();
            log.ShowDialog();
        }

        private void content_Paint(object sender, PaintEventArgs e)
        {
            content.color = Color.FromArgb(229, 126, 49);
        }


        private void spSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSSUser ser = new NewSSUser();
            ser.ShowDialog();
        }

        private void plSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSPUser ser = new NewSPUser();
            ser.ShowDialog();
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewReportUser rep = new NewReportUser();
            rep.ShowDialog();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewViewUser view = new NewViewUser();
            view.ShowDialog();
        }

        private void complQuerryButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewComplUser cmq = new NewComplUser();
            cmq.ShowDialog();
        }

        private void NewMod_Load(object sender, EventArgs e)
        {

        }
        void PopulateComboBoxN()
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select distinct nationality from Players", sqlCon);
                DataTable dtb = new DataTable();
                sqlDa.Fill(dtb);
                nationalitycmbx.ValueMember = "nationality";
                nationalitycmbx.DisplayMember = "nationality";
                nationalitycmbx.DataSource = dtb;
                natcmbx.ValueMember = "nationality";
                natcmbx.DisplayMember = "nationality";
                natcmbx.DataSource = dtb;
            }
        }
        void PopulateComboBoxPp()
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select distinct position_in_team from Players", sqlCon);
                DataTable dtb = new DataTable();
                sqlDa.Fill(dtb);
                positioncmbx.ValueMember = "position_in_team";
                positioncmbx.DisplayMember = "position_in_team";
                positioncmbx.DataSource = dtb;
                positionplcmbx.ValueMember = "position_in_team";
                positionplcmbx.DisplayMember = "position_in_team";
                positionplcmbx.DataSource = dtb;
            }
        }
        private void UpdateBinding()
        {
            dataGridView1.DataSource = pl;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void agebutton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (namepltextBox.Text == "")
            {
                if (agecomboBox.Text == "=")
                {
                    pl = db.GetPlayerAgeEq(Convert.ToInt32(ageTextBox.Text));
                }
                if (agecomboBox.Text == "<")
                {
                    pl = db.GetPlayerAgeLes(Convert.ToInt32(ageTextBox.Text));
                }
                if (agecomboBox.Text == ">")
                {
                    pl = db.GetPlayerAgeMore(Convert.ToInt32(ageTextBox.Text));
                }
            }
            else
            {
                if (agecomboBox.Text == "=")
                {
                    pl = db.GetPlayerAgeEqClubs(Convert.ToInt32(ageTextBox.Text), club_idTextBox.Text);
                }
                if (agecomboBox.Text == "<")
                {
                    pl = db.GetPlayerAgeLesClubs(Convert.ToInt32(ageTextBox.Text), club_idTextBox.Text);
                }
                if (agecomboBox.Text == ">")
                {
                    pl = db.GetPlayerAgeMoreClubs(Convert.ToInt32(ageTextBox.Text), club_idTextBox.Text);
                }
            }
            UpdateBinding();
        }

        private void posButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (club_idTextBox.Text != "")
            {
                pl = db.GetPlayerPositionInTeamClubs(positionplcmbx.Text, club_idTextBox.Text);
            }
            else
            {
                pl = db.GetPlayerPositionInTeam(positionplcmbx.Text);
            }
            UpdateBinding();
        }

        private void clubButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            pl = db.GetPlayers(club_idTextBox.Text);
            UpdateBinding();
        }

        private void nameButton_Click(object sender, EventArgs e)
        {
            if (club_idTextBox.Text == "")
            {
                DataAccess db = new DataAccess();
                pl = db.GetPlayerName(namepltextBox.Text);
                UpdateBinding();
            }
            else
            {
                DataAccess db = new DataAccess();
                pl = db.GetPlayerNameClubs(namepltextBox.Text, club_idTextBox.Text);
                UpdateBinding();
            }
        }

        private void nationalityButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (club_idTextBox.Text != "")
            {
                pl = db.GetPlayerNationalityClubs(natcmbx.Text, club_idTextBox.Text);
            }
            else
            {
                pl = db.GetPlayerNationality(natcmbx.Text);
            }
            UpdateBinding();
        }

        private void wageButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (club_idTextBox.Text == "")
            {
                if (wageComboBox.Text == "=")
                {
                    pl = db.GetPlayerWageEq(Convert.ToInt32(plwageTextBox.Text));
                }
                if (wageComboBox.Text == "<")
                {
                    pl = db.GetPlayerWageLes(Convert.ToInt32(plwageTextBox.Text));
                }
                if (wageComboBox.Text == ">")
                {
                    pl = db.GetPlayerWageMore(Convert.ToInt32(plwageTextBox.Text));
                }
            }
            else
            {
                if (wageComboBox.Text == "=")
                {
                    pl = db.GetPlayerWageEqClubs(Convert.ToInt32(plwageTextBox.Text), club_idTextBox.Text);
                }
                if (wageComboBox.Text == "<")
                {
                    pl = db.GetPlayerWageLesClubs(Convert.ToInt32(plwageTextBox.Text), club_idTextBox.Text);
                }
                if (wageComboBox.Text == ">")
                {
                    pl = db.GetPlayerWageMoreClubs(Convert.ToInt32(plwageTextBox.Text), club_idTextBox.Text);
                }
            }
            UpdateBinding();
        }

        private void numButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (club_idTextBox.Text != "")
            {
                pl = db.GetPlayerNumberInTeamClubs(Convert.ToInt32(numberTextBox.Text), club_idTextBox.Text);
            }
            else
            {
                pl = db.GetPlayerNumberInTeam(Convert.ToInt32(numberTextBox.Text));
            }
            UpdateBinding();
        }

        private void heightButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (club_idTextBox.Text == "")
            {
                if (heightComboBox.Text == "=")
                {
                    pl = db.GetPlayerHeightEq(Convert.ToInt32(heightTextBox.Text));
                }
                if (heightComboBox.Text == "<")
                {
                    pl = db.GetPlayerHeightLes(Convert.ToInt32(heightTextBox.Text));
                }
                if (heightComboBox.Text == ">")
                {
                    pl = db.GetPlayerHeightMore(Convert.ToInt32(heightTextBox.Text));
                }
            }
            else
            {
                if (heightComboBox.Text == "=")
                {
                    pl = db.GetPlayerHeightEqClubs(Convert.ToInt32(heightTextBox.Text), club_idTextBox.Text);
                }
                if (heightComboBox.Text == "<")
                {
                    pl = db.GetPlayerHeightLesClubs(Convert.ToInt32(heightTextBox.Text), club_idTextBox.Text);
                }
                if (heightComboBox.Text == ">")
                {
                    pl = db.GetPlayerHeightMoreClubs(Convert.ToInt32(heightTextBox.Text), club_idTextBox.Text);
                }
            }
            UpdateBinding();
        }

        private void weightButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            if (club_idTextBox.Text == "")
            {
                if (weightComboBox.Text == "=")
                {
                    pl = db.GetPlayerWeightEq(Convert.ToInt32(weightTextBox.Text));
                }
                if (weightComboBox.Text == "<")
                {
                    pl = db.GetPlayerWeightLes(Convert.ToInt32(weightTextBox.Text));
                }
                if (weightComboBox.Text == ">")
                {
                    pl = db.GetPlayerWeightMore(Convert.ToInt32(weightTextBox.Text));
                }
            }
            else
            {
                if (weightComboBox.Text == "=")
                {
                    pl = db.GetPlayerWeightEqClubs(Convert.ToInt32(weightTextBox.Text), club_idTextBox.Text);
                }
                if (weightComboBox.Text == "<")
                {
                    pl = db.GetPlayerWeightLesClubs(Convert.ToInt32(weightTextBox.Text), club_idTextBox.Text);
                }
                if (weightComboBox.Text == ">")
                {
                    pl = db.GetPlayerWeightMoreClubs(Convert.ToInt32(weightTextBox.Text), club_idTextBox.Text);
                }
            }
            UpdateBinding();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    }
}
