﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class NewReportUser : Form
    {
        List<Reports> reports = new List<Reports>();
        List<PlReport> plrep = new List<PlReport>();
        List<ClubProfit> prof = new List<ClubProfit>();
        List<trWages> trrep = new List<trWages>();
        public NewReportUser()
        {
            InitializeComponent();
            modificationButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            modificationButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            reportButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            reportButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            viewButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            viewButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);

        }


        private void logoPanel_Paint(object sender, PaintEventArgs e)
        {
            logoPanel.BackColor = Color.FromArgb(229, 126, 49);
        }

        private void sidePanel_Paint(object sender, PaintEventArgs e)
        {
            sidePanel.BackColor = Color.FromArgb(41, 53, 65);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn log = new LogIn();
            log.ShowDialog();
        }

        private void content_Paint(object sender, PaintEventArgs e)
        {
            content.color = Color.FromArgb(229, 126, 49);
        }


        private void spSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSSUser ser = new NewSSUser();
            ser.ShowDialog();
        }

        private void plSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSPUser ser = new NewSPUser();
            ser.ShowDialog();
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewReportUser rep = new NewReportUser();
            rep.ShowDialog();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewViewUser view = new NewViewUser();
            view.ShowDialog();
        }

        private void complQuerryButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewComplUser cmq = new NewComplUser();
            cmq.ShowDialog();
        }

        private void NewMod_Load(object sender, EventArgs e)
        {

        }

        private void UpdateBindingAdmin()
        {
            dataGridView1.DataSource = reports;
        }

        private void UpdateBindingPl()
        {
            plwagesListBox.DataSource = plrep;
            plwagesListBox.DisplayMember = "Info";
        }
        private void UpdateBindingOw()
        {
            profitListBox.DataSource = prof;
            profitListBox.DisplayMember = "Info";
        }
        private void UpdateBindingTr()
        {
            trWagesListBox.DataSource = trrep;
            trWagesListBox.DisplayMember = "Info";
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            reports = db.GetReport(nameTextBox.Text);
            UpdateBindingAdmin();
        }

        private void content_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            plrep = db.GetPlayersWage(nameTextBox.Text, Convert.ToDecimal(dateTextBox.Text));
            prof = db.GetProfit(nameTextBox.Text, Convert.ToDecimal(dateTextBox.Text));
            trrep = db.GetTrainersWage(nameTextBox.Text, Convert.ToDecimal(dateTextBox.Text));
            UpdateBindingPl();
            UpdateBindingOw();
            UpdateBindingTr();
            totalLabel.Text = (Convert.ToInt32(trWagesListBox.Text) + Convert.ToInt32(plwagesListBox.Text)).ToString();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    }
}
