﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace FormUI
{
    public class DataAccess
    {
        public List<Stadium> GetStadiums(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                return connection.Query<Stadium>($"SELECT * from stadiums where name = '{ name }'").ToList();
            }
        }

        public void InsertStaduim(string Name, string Country, string City, int Capacity)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                Stadium newStadium = new Stadium { name = Name, country = Country, city = City, capacity = Capacity };
                List<Stadium> stadiums = new List<Stadium>();
                stadiums.Add(newStadium);
                connection.Execute("stadium_insert @name, @country, @city, @capacity", stadiums);
            }
        }

        internal List<Stadium> GetStadiums()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
              return connection.Query<Stadium>($"SELECT top (50) * from stadiums order by ID desc").ToList();
            }
        }

        internal void UpdateStadiumName(Stadium stad, string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                connection.Execute($"Update Stadiums Set name = '{ name }' where ID = @id AND name = @name and country = @country and city = @city and capacity = @capacity", stad);
            }
        }

        internal void UpdateStadiumCity(Stadium stad, string city)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                connection.Execute($"Update Stadiums Set city = '{ city }' where ID = @id AND name = @name and country = @country and city = @city and capacity = @capacity", stad);
            }
        }

        internal void UpdateStadiumCapacity(Stadium stad, int capacity)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                connection.Execute($"Update Stadiums Set capacity = '{ capacity }' where ID = @id AND name = @name and country = @country and city = @city and capacity = @capacity", stad);
            }
        }

        internal void UpdateStadiumCountry(Stadium stad, string country)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                connection.Execute($"Update Stadiums Set country = '{ country }' where ID = @id AND name = @name and country = @country and city = @city and capacity = @capacity", stad);
            }
        }

        internal void DeleteStadium(Stadium stad)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                connection.Execute($"DELETE FROM Stadiums where ID = @id AND name = @name and country = @country and city = @city and capacity = @capacity", stad);
            }
        }

        internal List<Sponsors> GetSpName(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_name '{ name }'").ToList();
            }
        }

        internal List<Sponsors> GetSpId_Name(int id, string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_id_name { id }, '{ name }'").ToList();
            }
        }

        internal List<Sponsors> GetSpId_Service(int id, string service)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_id_service { id }, '{ service }'").ToList();
            }
        }

        internal List<Sponsors> GetSpName_Service(string name, string service)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_name_service '{ name }', '{ service }'").ToList();
            }
        }

        internal List<Sponsors> GetSpId_Name_Service(int id, string name, string service)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_id_name_service { id }, '{ name }', '{ service }'").ToList();
            }
        }

        internal List<Sponsors> GetSpService(string service)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_service '{ service }'").ToList();
            }
        }

        internal List<Sponsors> GetSpId(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Sponsors>($"exec sp_id { id }").ToList();
            }
        }

        internal List<ClubStatistics> GetStatistics(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<ClubStatistics>($"SELECT Clubs_Statistics.rank, Clubs_Statistics.Club_ID, Clubs_Statistics.number_of_wins, Clubs_Statistics.number_of_lesions, Clubs_Statistics.draw_number from Clubs_Statistics inner join Clubs On Clubs.ID = Clubs_Statistics.Club_ID WHERE Clubs.name = '{ name }'").ToList();
            }
        }

        internal List<Players> GetPlayerAgeMore(int age)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_age_more { age }").ToList();
            }
        }

        internal List<Players> GetPlayerAgeEqClubs(int age, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_age_eq_cl { age } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerAgeMoreClubs(int age, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_age_more_cl { age } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerNationalityClubs(string nationality, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_nationality_clubs '{ nationality }' , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerNationality(string nationality)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_nationality { nationality }").ToList();
            }
        }

        internal List<Players> GetPlayerWageLes(int wage)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_wage_les { wage }").ToList();
            }
        }

        internal List<Players> GetPlayerWageEqClubs(int wage, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_wage_eq_cl { wage } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerWageMoreClubs(int wage, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_wage_more_cl { wage } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerPositionInTeamClubs(string pos, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_pos_clubs '{ pos }', '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerWageLesClubs(int wage, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_wage_les_cl { wage } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerNumberInTeamClubs(int num, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_num_clubs { num }, '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerHeightEq(int height)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_height_eq { height }").ToList();
            }
        }

        internal List<Players> GetPlayerHeightMore(int height)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_height_more { height }").ToList();
            }
        }

        internal List<Players> GetPlayerHeightLesClubs(int height, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_height_les_cl { height } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerHeightMoreClubs(int height, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_height_more_cl { height } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerWeightEq(int weight)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_weight_eq { weight }").ToList();
            }
        }

        internal List<Players> GetPlayerWeightMore(int weight)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_weight_more { weight }").ToList();
            }
        }

        internal List<Players> GetPlayerWeightLesClubs(int weight, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_weight_les_cl { weight } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerWeightMoreClubs(int weight, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_weight_more_cl { weight } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerID_Clubs(int id, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec pl_id_clubs { id }, '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerID(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec pl_id { id }").ToList();
            }
        }

        internal List<Players> GetPlayerWeightEqClubs(int weight, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_weight_eq_cl { weight } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerWeightLes(int weight)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_weight_les { weight }").ToList();
            }
        }

        internal List<Players> GetPlayerHeightEqClubs(int height, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_height_eq_cl { height } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerHeightLes(int height)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_height_les { height }").ToList();
            }
        }

        internal List<Players> GetPlayerNumberInTeam(int num)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_num { num }").ToList();
            }
        }

        internal List<Players> GetPlayerPositionInTeam(string pos)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_pos '{ pos }'").ToList();
            }
        }

        internal List<Players> GetPlayerWageMore(int wage)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_wage_more { wage }").ToList();
            }
        }

        internal List<Players> GetPlayerWageEq(int wage)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_wage_eq { wage }").ToList();
            }
        }

        internal List<Players> GetPlayerAgeLesClubs(int age, string club_name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_age_les_cl { age } , '{ club_name }'").ToList();
            }
        }

        internal List<Players> GetPlayerAgeLes(int age)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_age_les { age }").ToList();
            }
        }

        internal List<Players> GetPlayerAgeEq(int plage)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_age_eq { plage }").ToList();
            }
        }

        internal List<Players> GetPlayerNameClubs(string plname, string clubname)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_names_clubs '{ plname }', '{ clubname }'").ToList();
            }
        }

        internal List<Clubs> GetClubs(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                return connection.Query<Clubs>($"SELECT Clubs.ID, date_of_establishment, Clubs.name as name, Stadiums.name as Stadium_name, Stadium_ID from Clubs inner join stadiums on Stadium_ID = Stadiums.ID where Clubs.name = '{ name }'").ToList();
            }
        }

        internal List<Players> GetPlayerName(string plname)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Players>($"exec player_names '{ plname }'").ToList();
            }
        }

        internal List<Players> GetPlayers(string clubName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                return connection.Query<Players>($"select Players.ID, Club_ID, Players.name, age, nationality, wage, position_in_team, number_in_team, height, weight from players inner join clubs on Club_ID = Clubs.ID where Clubs.name = '{ clubName }'").ToList();
            }
        }

        internal List<Trainers> GetTrainers(string clubName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                return connection.Query<Trainers>($"select trainers.ID, Club_ID, full_name, date_of_birth, position, wage, date_of_appointment, dismissal_date from Trainers inner join Clubs ON Clubs.ID = Club_ID WHERE Clubs.name = '{ clubName }'").ToList();
            }
        }

        internal List<PlayersView> GetPlayersView()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                return connection.Query<PlayersView>($"select top (50) * from Players_Trainers order by ID desc").ToList();
            }
        }

        public void InsertView(string Name, int Age, string Nationality, Decimal Wage, string PositionInTeam, int NumberInTeam, int Height, int Weight, DateTime birth, string full_name, string position, decimal trwage, DateTime app, int club_id, int tr_club_id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                PlayersView view = new PlayersView { name = Name, age = Age, nationality = Nationality, wage = Wage, position_in_team = PositionInTeam, number_in_team = NumberInTeam, height = Height, weight = Weight, date_of_birth = birth, full_name = full_name, position = position, Trainer_wage = trwage, date_of_appointment = app, Club_ID = club_id, Tr_Club = tr_club_id};
                List<PlayersView> pv = new List<PlayersView>();
                pv.Add(view);
                connection.Execute($"insert into Players_Trainers (name, age, nationality, wage, position_in_team, number_in_team, height, weight, date_of_birth, full_name, position, Trainer_wage, date_of_appointment, Club_ID, Tr_Club) values (@name, @age, @nationality, @wage, @position_in_team, @number_in_team, @height, @weight, @date_of_birth, @full_name, @position, @Trainer_wage, @date_of_appointment, @Club_ID, @Tr_Club)", pv);
            }
        }
        internal List<Reports> GetReport(string clubName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {

                return connection.Query<Reports>($"select name, Player_wage * 1000 as pwage, position_in_team, full_name, position, wage from report1 where Player_club_ID = (Select ID FROm Clubs where name = '{ clubName }')").ToList();
            }
        }

        internal List<PlReport> GetPlayersWage(string ClubName, Decimal Year)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<PlReport>($"SELECT sum (Player_wage * 1000 * (2019 - { Year } + 1)) as cost From report1 WHERE  Player_club_ID = (Select ID FROm Clubs where name = '{ ClubName }')").ToList();
            }
        }
        internal List<ClubProfit> GetProfit(string clubName, decimal Year)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<ClubProfit>($"SELECt club_Profit * (2019 - { Year } + 1) as profit From Owners where Club_ID = (SELECT ID FROM Clubs where name = '{ clubName }' )").ToList();
            }
        }
        internal List<trWages> GetTrainersWage(string clubName, decimal Year)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<trWages>($"SELECT sum (wage * (2019 - { Year } + 1)) as trwage From report1 WHERE  Player_club_ID = (Select ID FROm Clubs where name = '{ clubName }')").ToList();
            }
        }

        internal List<Everything> GetTrainer(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Everything>($"SELECT distinct ID , Club_ID , full_name , date_of_birth , position , wage , date_of_appointment , dismissal_date from Search where full_name = '{ name }'").ToList();
            }
        }
        internal List<Everything> GetPlayer(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Everything>($"SELECT distinct   Players_ID, Players_Club_ID, Players_Name, age , nationality, Players_wage , position_in_team , number_in_team , weight , height from Search where Players_Name = '{ name }'").ToList();
            }
        }
        internal List<Everything> GetClub(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Everything>($"SELECT distinct   Clubs_ID , date_of_establishment , Clubs_name , Stadium_ID from Search where Clubs_name = '{ name }'").ToList();
            }
        }
        internal List<Everything> GetOwner(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Everything>($"SELECT distinct Owners_ID, Owners_Club_ID , Sponsor_ID, Owners_full_name , Owners_date_of_birth , club_Profit, club_Purchase_Date, club_Sale_Date from Search where Owners_full_name = '{ name }'").ToList();
            }
        }
        internal List<Everything> GetStadium(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Everything>($"SELECT distinct Stad_ID, name , country, city, capacity from Search where name = '{ name }'").ToList();
            }
        }
        internal List<Everything> GetSponsor(string name)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Football_LeagueDB")))
            {
                return connection.Query<Everything>($"SELECT distinct Sponsors_ID, Sponsors_name, service from Search where Sponsors_name = '{ name }'").ToList();
            }
        }

    }
}