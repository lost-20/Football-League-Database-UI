﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
   public class PlayersView
    {
        public string name { get; set; }
        public int age { get; set; }
        public string nationality { get; set; }
        public decimal wage { get; set; }
        public string position_in_team { get; set; }
        public int number_in_team { get; set; }
        public int height { get; set; }
        public int weight { get; set; }
        public int ID { get; set; }
        public DateTime date_of_birth { get; set; }
        public string full_name { get; set; }
        public string position { get; set; }
        public Decimal Trainer_wage { get; set; }
        public DateTime date_of_appointment { get; set; }
        public int Club_ID { get; set; }
        public int Tr_Club { get; set; }
    }
}
