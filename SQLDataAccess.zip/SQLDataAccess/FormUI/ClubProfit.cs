﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
   public class ClubProfit
    {
        public decimal profit { get; set; }
        public string Info
        {
            get
            {
                return $"{ profit }";
            }
        }
    }
}
