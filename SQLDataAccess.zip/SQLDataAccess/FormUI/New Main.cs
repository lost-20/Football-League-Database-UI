﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class NewMain : Form
    {
        public NewMain()
        {
            InitializeComponent();
            modificationButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            modificationButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            reportButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            reportButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            viewButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            viewButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
        }


        private void logoPanel_Paint(object sender, PaintEventArgs e)
        {
            logoPanel.BackColor = Color.FromArgb(229, 126, 49);
        }

        private void sidePanel_Paint(object sender, PaintEventArgs e)
        {
            sidePanel.BackColor = Color.FromArgb(41, 53, 65);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn log = new LogIn();
            log.ShowDialog();
        }

        private void content_Paint(object sender, PaintEventArgs e)
        {
            content.color = Color.FromArgb(229, 126, 49);
        }


        private void modificationButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSelect mod = new NewSelect();
            mod.ShowDialog();
        }
        private void spSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSS ser = new NewSS();
            ser.ShowDialog();
        }

        private void plSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSP ser = new NewSP();
            ser.ShowDialog();
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewReport rep = new NewReport();
            rep.ShowDialog();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewView view = new NewView();
            view.ShowDialog();
        }

        private void complQuerryButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewCompl cmq = new NewCompl();
            cmq.ShowDialog();
        }
    }
}
