﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class NewViewUser : Form
    {
        string connectionString = @"Server=W12-418-29;DataBase=Football_League;Trusted_Connection=True";
        List<PlayersView> pl = new List<PlayersView>();
        public NewViewUser()
        {
            InitializeComponent();
            modificationButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            modificationButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            reportButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            reportButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            viewButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            viewButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            PopulateComboBoxN();
            PopulateComboBoxPp();
            PopulateComboBoxPt();
        }


        private void logoPanel_Paint(object sender, PaintEventArgs e)
        {
            logoPanel.BackColor = Color.FromArgb(229, 126, 49);
        }

        private void sidePanel_Paint(object sender, PaintEventArgs e)
        {
            sidePanel.BackColor = Color.FromArgb(41, 53, 65);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn log = new LogIn();
            log.ShowDialog();
        }

        private void content_Paint(object sender, PaintEventArgs e)
        {
            content.color = Color.FromArgb(229, 126, 49);
        }

        private void spSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSSUser ser = new NewSSUser();
            ser.ShowDialog();
        }

        private void plSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSPUser ser = new NewSPUser();
            ser.ShowDialog();
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewReportUser rep = new NewReportUser();
            rep.ShowDialog();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewViewUser view = new NewViewUser();
            view.ShowDialog();
        }

        private void complQuerryButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewComplUser cmq = new NewComplUser();
            cmq.ShowDialog();
        }

        private void NewMod_Load(object sender, EventArgs e)
        {

        }
        void PopulateComboBoxN()
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select distinct nationality from Players_Trainers", sqlCon);
                DataTable dtb = new DataTable();
                sqlDa.Fill(dtb);
                nationalitycmbx.ValueMember = "nationality";
                nationalitycmbx.DisplayMember = "nationality";
                nationalitycmbx.DataSource = dtb;
                natcmbx.ValueMember = "nationality";
                natcmbx.DisplayMember = "nationality";
                natcmbx.DataSource = dtb;
            }
        }
        void PopulateComboBoxPp()
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select distinct position_in_team from Players_Trainers", sqlCon);
                DataTable dtb = new DataTable();
                sqlDa.Fill(dtb);
                positioncmbx.ValueMember = "position_in_team";
                positioncmbx.DisplayMember = "position_in_team";
                positioncmbx.DataSource = dtb;
                positionplcmbx.ValueMember = "position_in_team";
                positionplcmbx.DisplayMember = "position_in_team";
                positionplcmbx.DataSource = dtb;
            }
        }
        void PopulateComboBoxPt()
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select distinct position from Players_Trainers", sqlCon);
                DataTable dtb = new DataTable();
                sqlDa.Fill(dtb);
                poscmbx.ValueMember = "position";
                poscmbx.DisplayMember = "position";
                poscmbx.DataSource = dtb;
                postrcmbx.ValueMember = "position";
                postrcmbx.DisplayMember = "position";
                postrcmbx.DataSource = dtb;
            }
        }
        void PopulateDataGridView()
        {
            DataAccess db = new DataAccess();
            pl = db.GetPlayersView();
            UpdateBinding();
        }
        private void UpdateBinding()
        {
            dataGridView1.DataSource = pl;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            PopulateDataGridView();
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            db.InsertView(namepltextBox.Text, Convert.ToInt32(ageTextBox.Text), natcmbx.Text, Convert.ToDecimal(plwageTextBox.Text), positionplcmbx.Text, Convert.ToInt32(numberTextBox.Text), Convert.ToInt32(heightTextBox.Text), Convert.ToInt32(weightTextBox.Text), Convert.ToDateTime(datebTextBox.Text), fullnameTextBox.Text, postrcmbx.Text, Convert.ToDecimal(trwageTextBox.Text), Convert.ToDateTime(dateaTextBox.Text), Convert.ToInt32(club_idTextBox.Text), Convert.ToInt32(club_idTextBox.Text));
            namepltextBox.Text = "";
            ageTextBox.Text = "";
            plwageTextBox.Text = "";
            numberTextBox.Text = "";
            heightTextBox.Text = "";
            weightTextBox.Text = "";
            trwageTextBox.Text = "";
            club_idTextBox.Text = "";
            dateaTextBox.Text = "";
            datebTextBox.Text = "";
            fullnameTextBox.Text = "";
        }

        private void label19_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label20_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    }
}
