﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class NewModInj : Form
    {
        string connectionString = @"Server=W12-418-29;DataBase=Football_League;Trusted_Connection=True";
        List<Stadium> st = new List<Stadium>();
        public NewModInj()
        {
            InitializeComponent();
            modificationButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            modificationButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            complQuerryButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            reportButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            reportButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            viewButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            viewButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            plSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.IdleFillColor = Color.FromArgb(41, 53, 65);
            spSearchButton.DisabledFillColor = Color.FromArgb(41, 53, 65);
            PopulateDataGridView();
        }


        private void logoPanel_Paint(object sender, PaintEventArgs e)
        {
            logoPanel.BackColor = Color.FromArgb(229, 126, 49);
        }

        private void sidePanel_Paint(object sender, PaintEventArgs e)
        {
            sidePanel.BackColor = Color.FromArgb(41, 53, 65);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn log = new LogIn();
            log.ShowDialog();
        }

        private void content_Paint(object sender, PaintEventArgs e)
        {
            content.color = Color.FromArgb(229, 126, 49);
        }

        private void modificationButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSelect mod = new NewSelect();
            mod.ShowDialog();
        }

        private void spSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSS ser = new NewSS();
            ser.ShowDialog();
        }

        private void plSearchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewSP ser = new NewSP();
            ser.ShowDialog();
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewReport rep = new NewReport();
            rep.ShowDialog();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewView view = new NewView();
            view.ShowDialog();
        }

        private void complQuerryButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewCompl cmq = new NewCompl();
            cmq.ShowDialog();
        }

        private void NewMod_Load(object sender, EventArgs e)
        {

        }
        void PopulateDataGridView()
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("select  * from Injured_Players order by Player_ID", sqlCon);
                DataTable dtb = new DataTable();
                sqlDa.Fill(dtb);
                dataGridView1.DataSource = dtb;
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    DataGridViewRow row = dataGridView1.CurrentRow;
                    SqlCommand sqlCom = new SqlCommand("injured_insert", sqlCon);
                    sqlCom.CommandType = CommandType.StoredProcedure;
                    if (row.Cells["type"].Value == DBNull.Value)
                        sqlCom.Parameters.AddWithValue("@help", 0);
                    else
                        sqlCom.Parameters.AddWithValue("@help", 1);
                    sqlCom.Parameters.AddWithValue("@ID", Convert.ToInt32(row.Cells["IDpl"].Value == DBNull.Value ? "1" : row.Cells["IDpl"].Value.ToString()));
                    sqlCom.Parameters.AddWithValue("@match", Convert.ToInt32(row.Cells["IDm"].Value == DBNull.Value ? "1" : row.Cells["IDm"].Value.ToString()));
                    sqlCom.Parameters.AddWithValue("@type", row.Cells["type"].Value.ToString());
                    sqlCom.Parameters.AddWithValue("@rec", Convert.ToInt32(row.Cells["recovery"].Value == DBNull.Value ? "0" : row.Cells["recovery"].Value.ToString()));
                    sqlCom.ExecuteNonQuery();
                    PopulateDataGridView();
                }
            }
        }
    }
}
