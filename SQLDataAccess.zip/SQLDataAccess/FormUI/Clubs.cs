﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Clubs
    {
        public int ID { get; set; }
        public DateTime date_of_establishment { get; set; }
        public string name { get; set; }
        public string Stadium_name { get; set; }
        public int Stadium_ID { get; set; }
    }
}
