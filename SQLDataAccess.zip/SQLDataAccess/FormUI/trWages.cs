﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class trWages
    {
        public decimal trwage { get; set; }
        public string Info
        {
            get
            {
                return $"{ trwage }";
            }
        }
    }
}
