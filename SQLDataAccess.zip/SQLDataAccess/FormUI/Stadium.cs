﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Stadium
    {
        public int ID { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string city { get; set; }
        public int capacity { get; set; }
        public string FullInfo
        {
            get
            {
                return $"{ ID } { name } { country } { city } { capacity }";
            }
        }
        public string UserInfo
        {
            get
            {
                return $"{ name } { country } { city } { capacity }";
            }
        }
        public int getID { get { return ID; } }
    }
}
