﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Trainers
    {
        public int ID { get; set; }
        public int Club_ID { get; set; }
        public string full_name { get; set; }
        public DateTime date_of_birth { get; set; }
        public string position { get; set; }
        public int wage { get; set; }
        public DateTime date_of_appointment { get; set; }
        public DateTime dismissal_date { get; set; }
    }
}
