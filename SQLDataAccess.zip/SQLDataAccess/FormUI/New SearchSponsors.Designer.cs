﻿namespace FormUI
{
    partial class NewSS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewSS));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges23 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges24 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges25 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges26 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges27 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges28 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.sidePanel = new System.Windows.Forms.Panel();
            this.modificationButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.complQuerryButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.plSearchButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.spSearchButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.viewButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.reportButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.logoPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.content = new Bunifu.Framework.UI.BunifuCards();
            this.clubButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.serviceTextBox = new Bunifu.Framework.BunifuCustomTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.nameTextBox = new Bunifu.Framework.BunifuCustomTextbox();
            this.label6 = new System.Windows.Forms.Label();
            this.idTextBox = new Bunifu.Framework.BunifuCustomTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.service = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stadiumsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.footballLeagueDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.sidePanel.SuspendLayout();
            this.logoPanel.SuspendLayout();
            this.headerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.content.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stadiumsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.footballLeagueDataSetBindingSource)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidePanel
            // 
            this.sidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sidePanel.Controls.Add(this.modificationButton);
            this.sidePanel.Controls.Add(this.complQuerryButton);
            this.sidePanel.Controls.Add(this.plSearchButton);
            this.sidePanel.Controls.Add(this.spSearchButton);
            this.sidePanel.Controls.Add(this.viewButton);
            this.sidePanel.Controls.Add(this.reportButton);
            this.sidePanel.Controls.Add(this.logoPanel);
            this.sidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidePanel.Location = new System.Drawing.Point(0, 0);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(284, 525);
            this.sidePanel.TabIndex = 0;
            this.sidePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.sidePanel_Paint);
            // 
            // modificationButton
            // 
            this.modificationButton.AllowToggling = false;
            this.modificationButton.AnimationSpeed = 200;
            this.modificationButton.AutoGenerateColors = false;
            this.modificationButton.BackColor = System.Drawing.Color.Transparent;
            this.modificationButton.BackColor1 = System.Drawing.Color.Black;
            this.modificationButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("modificationButton.BackgroundImage")));
            this.modificationButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.ButtonText = "Модификация базы данных";
            this.modificationButton.ButtonTextMarginLeft = 0;
            this.modificationButton.ColorContrastOnClick = 45;
            this.modificationButton.ColorContrastOnHover = 45;
            this.modificationButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges22.BottomLeft = true;
            borderEdges22.BottomRight = true;
            borderEdges22.TopLeft = true;
            borderEdges22.TopRight = true;
            this.modificationButton.CustomizableEdges = borderEdges22;
            this.modificationButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.modificationButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.modificationButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.modificationButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.modificationButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.modificationButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.modificationButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.modificationButton.ForeColor = System.Drawing.Color.White;
            this.modificationButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.modificationButton.IconMarginLeft = 11;
            this.modificationButton.IconPadding = 10;
            this.modificationButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.modificationButton.IdleBorderColor = System.Drawing.Color.White;
            this.modificationButton.IdleBorderRadius = 3;
            this.modificationButton.IdleBorderThickness = 1;
            this.modificationButton.IdleFillColor = System.Drawing.Color.Black;
            this.modificationButton.IdleIconLeftImage = null;
            this.modificationButton.IdleIconRightImage = null;
            this.modificationButton.IndicateFocus = false;
            this.modificationButton.Location = new System.Drawing.Point(0, 183);
            this.modificationButton.Name = "modificationButton";
            this.modificationButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.modificationButton.onHoverState.BorderRadius = 3;
            this.modificationButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.onHoverState.BorderThickness = 1;
            this.modificationButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.modificationButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.modificationButton.onHoverState.IconLeftImage = null;
            this.modificationButton.onHoverState.IconRightImage = null;
            this.modificationButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.modificationButton.OnIdleState.BorderRadius = 3;
            this.modificationButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.OnIdleState.BorderThickness = 1;
            this.modificationButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.modificationButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.modificationButton.OnIdleState.IconLeftImage = null;
            this.modificationButton.OnIdleState.IconRightImage = null;
            this.modificationButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.modificationButton.OnPressedState.BorderRadius = 3;
            this.modificationButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.OnPressedState.BorderThickness = 1;
            this.modificationButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.modificationButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.modificationButton.OnPressedState.IconLeftImage = null;
            this.modificationButton.OnPressedState.IconRightImage = null;
            this.modificationButton.Size = new System.Drawing.Size(284, 57);
            this.modificationButton.TabIndex = 9;
            this.modificationButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.modificationButton.TextMarginLeft = 0;
            this.modificationButton.UseDefaultRadiusAndThickness = true;
            this.modificationButton.Click += new System.EventHandler(this.modificationButton_Click);
            // 
            // complQuerryButton
            // 
            this.complQuerryButton.AllowToggling = false;
            this.complQuerryButton.AnimationSpeed = 200;
            this.complQuerryButton.AutoGenerateColors = false;
            this.complQuerryButton.BackColor = System.Drawing.Color.Transparent;
            this.complQuerryButton.BackColor1 = System.Drawing.Color.Black;
            this.complQuerryButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("complQuerryButton.BackgroundImage")));
            this.complQuerryButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.ButtonText = "Сложные запросы к базе данных";
            this.complQuerryButton.ButtonTextMarginLeft = 0;
            this.complQuerryButton.ColorContrastOnClick = 45;
            this.complQuerryButton.ColorContrastOnHover = 45;
            this.complQuerryButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges23.BottomLeft = true;
            borderEdges23.BottomRight = true;
            borderEdges23.TopLeft = true;
            borderEdges23.TopRight = true;
            this.complQuerryButton.CustomizableEdges = borderEdges23;
            this.complQuerryButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.complQuerryButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.complQuerryButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.complQuerryButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.complQuerryButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.complQuerryButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.complQuerryButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.complQuerryButton.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.complQuerryButton.IconMarginLeft = 11;
            this.complQuerryButton.IconPadding = 10;
            this.complQuerryButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.complQuerryButton.IdleBorderColor = System.Drawing.Color.White;
            this.complQuerryButton.IdleBorderRadius = 3;
            this.complQuerryButton.IdleBorderThickness = 1;
            this.complQuerryButton.IdleFillColor = System.Drawing.Color.Black;
            this.complQuerryButton.IdleIconLeftImage = null;
            this.complQuerryButton.IdleIconRightImage = null;
            this.complQuerryButton.IndicateFocus = false;
            this.complQuerryButton.Location = new System.Drawing.Point(0, 240);
            this.complQuerryButton.Name = "complQuerryButton";
            this.complQuerryButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.complQuerryButton.onHoverState.BorderRadius = 3;
            this.complQuerryButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.onHoverState.BorderThickness = 1;
            this.complQuerryButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.complQuerryButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.onHoverState.IconLeftImage = null;
            this.complQuerryButton.onHoverState.IconRightImage = null;
            this.complQuerryButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.complQuerryButton.OnIdleState.BorderRadius = 3;
            this.complQuerryButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.OnIdleState.BorderThickness = 1;
            this.complQuerryButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.complQuerryButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.OnIdleState.IconLeftImage = null;
            this.complQuerryButton.OnIdleState.IconRightImage = null;
            this.complQuerryButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.complQuerryButton.OnPressedState.BorderRadius = 3;
            this.complQuerryButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.OnPressedState.BorderThickness = 1;
            this.complQuerryButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.complQuerryButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.OnPressedState.IconLeftImage = null;
            this.complQuerryButton.OnPressedState.IconRightImage = null;
            this.complQuerryButton.Size = new System.Drawing.Size(284, 57);
            this.complQuerryButton.TabIndex = 8;
            this.complQuerryButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.complQuerryButton.TextMarginLeft = 0;
            this.complQuerryButton.UseDefaultRadiusAndThickness = true;
            this.complQuerryButton.Click += new System.EventHandler(this.complQuerryButton_Click);
            // 
            // plSearchButton
            // 
            this.plSearchButton.AllowToggling = false;
            this.plSearchButton.AnimationSpeed = 200;
            this.plSearchButton.AutoGenerateColors = false;
            this.plSearchButton.BackColor = System.Drawing.Color.Transparent;
            this.plSearchButton.BackColor1 = System.Drawing.Color.Black;
            this.plSearchButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plSearchButton.BackgroundImage")));
            this.plSearchButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.ButtonText = "Поиск игроков";
            this.plSearchButton.ButtonTextMarginLeft = 0;
            this.plSearchButton.ColorContrastOnClick = 45;
            this.plSearchButton.ColorContrastOnHover = 45;
            this.plSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges24.BottomLeft = true;
            borderEdges24.BottomRight = true;
            borderEdges24.TopLeft = true;
            borderEdges24.TopRight = true;
            this.plSearchButton.CustomizableEdges = borderEdges24;
            this.plSearchButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.plSearchButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.plSearchButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.plSearchButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.plSearchButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.plSearchButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.plSearchButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.plSearchButton.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.plSearchButton.IconMarginLeft = 11;
            this.plSearchButton.IconPadding = 10;
            this.plSearchButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.plSearchButton.IdleBorderColor = System.Drawing.Color.White;
            this.plSearchButton.IdleBorderRadius = 3;
            this.plSearchButton.IdleBorderThickness = 1;
            this.plSearchButton.IdleFillColor = System.Drawing.Color.Black;
            this.plSearchButton.IdleIconLeftImage = null;
            this.plSearchButton.IdleIconRightImage = null;
            this.plSearchButton.IndicateFocus = false;
            this.plSearchButton.Location = new System.Drawing.Point(0, 297);
            this.plSearchButton.Name = "plSearchButton";
            this.plSearchButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.plSearchButton.onHoverState.BorderRadius = 3;
            this.plSearchButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.onHoverState.BorderThickness = 1;
            this.plSearchButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.plSearchButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.onHoverState.IconLeftImage = null;
            this.plSearchButton.onHoverState.IconRightImage = null;
            this.plSearchButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.plSearchButton.OnIdleState.BorderRadius = 3;
            this.plSearchButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.OnIdleState.BorderThickness = 1;
            this.plSearchButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.plSearchButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.OnIdleState.IconLeftImage = null;
            this.plSearchButton.OnIdleState.IconRightImage = null;
            this.plSearchButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.plSearchButton.OnPressedState.BorderRadius = 3;
            this.plSearchButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.OnPressedState.BorderThickness = 1;
            this.plSearchButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.plSearchButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.OnPressedState.IconLeftImage = null;
            this.plSearchButton.OnPressedState.IconRightImage = null;
            this.plSearchButton.Size = new System.Drawing.Size(284, 57);
            this.plSearchButton.TabIndex = 7;
            this.plSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.plSearchButton.TextMarginLeft = 0;
            this.plSearchButton.UseDefaultRadiusAndThickness = true;
            this.plSearchButton.Click += new System.EventHandler(this.plSearchButton_Click);
            // 
            // spSearchButton
            // 
            this.spSearchButton.AllowToggling = false;
            this.spSearchButton.AnimationSpeed = 200;
            this.spSearchButton.AutoGenerateColors = false;
            this.spSearchButton.BackColor = System.Drawing.Color.Transparent;
            this.spSearchButton.BackColor1 = System.Drawing.Color.Black;
            this.spSearchButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("spSearchButton.BackgroundImage")));
            this.spSearchButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.ButtonText = "Поиск спонсоров";
            this.spSearchButton.ButtonTextMarginLeft = 0;
            this.spSearchButton.ColorContrastOnClick = 45;
            this.spSearchButton.ColorContrastOnHover = 45;
            this.spSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges25.BottomLeft = true;
            borderEdges25.BottomRight = true;
            borderEdges25.TopLeft = true;
            borderEdges25.TopRight = true;
            this.spSearchButton.CustomizableEdges = borderEdges25;
            this.spSearchButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.spSearchButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.spSearchButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.spSearchButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.spSearchButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.spSearchButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.spSearchButton.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.spSearchButton.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.spSearchButton.IconMarginLeft = 11;
            this.spSearchButton.IconPadding = 10;
            this.spSearchButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.spSearchButton.IdleBorderColor = System.Drawing.Color.White;
            this.spSearchButton.IdleBorderRadius = 3;
            this.spSearchButton.IdleBorderThickness = 1;
            this.spSearchButton.IdleFillColor = System.Drawing.Color.Black;
            this.spSearchButton.IdleIconLeftImage = null;
            this.spSearchButton.IdleIconRightImage = null;
            this.spSearchButton.IndicateFocus = false;
            this.spSearchButton.Location = new System.Drawing.Point(0, 354);
            this.spSearchButton.Name = "spSearchButton";
            this.spSearchButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.spSearchButton.onHoverState.BorderRadius = 3;
            this.spSearchButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.onHoverState.BorderThickness = 1;
            this.spSearchButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.spSearchButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.onHoverState.IconLeftImage = null;
            this.spSearchButton.onHoverState.IconRightImage = null;
            this.spSearchButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.spSearchButton.OnIdleState.BorderRadius = 3;
            this.spSearchButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.OnIdleState.BorderThickness = 1;
            this.spSearchButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.spSearchButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.OnIdleState.IconLeftImage = null;
            this.spSearchButton.OnIdleState.IconRightImage = null;
            this.spSearchButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.spSearchButton.OnPressedState.BorderRadius = 3;
            this.spSearchButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.OnPressedState.BorderThickness = 1;
            this.spSearchButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.spSearchButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.OnPressedState.IconLeftImage = null;
            this.spSearchButton.OnPressedState.IconRightImage = null;
            this.spSearchButton.Size = new System.Drawing.Size(284, 57);
            this.spSearchButton.TabIndex = 6;
            this.spSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.spSearchButton.TextMarginLeft = 0;
            this.spSearchButton.UseDefaultRadiusAndThickness = true;
            this.spSearchButton.Click += new System.EventHandler(this.spSearchButton_Click);
            // 
            // viewButton
            // 
            this.viewButton.AllowToggling = false;
            this.viewButton.AnimationSpeed = 200;
            this.viewButton.AutoGenerateColors = false;
            this.viewButton.BackColor = System.Drawing.Color.Transparent;
            this.viewButton.BackColor1 = System.Drawing.Color.Black;
            this.viewButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("viewButton.BackgroundImage")));
            this.viewButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.ButtonText = "Вставка в представление игроков и тренеров";
            this.viewButton.ButtonTextMarginLeft = 0;
            this.viewButton.ColorContrastOnClick = 45;
            this.viewButton.ColorContrastOnHover = 45;
            this.viewButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges26.BottomLeft = true;
            borderEdges26.BottomRight = true;
            borderEdges26.TopLeft = true;
            borderEdges26.TopRight = true;
            this.viewButton.CustomizableEdges = borderEdges26;
            this.viewButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.viewButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.viewButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.viewButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.viewButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.viewButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.viewButton.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.viewButton.ForeColor = System.Drawing.Color.White;
            this.viewButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.viewButton.IconMarginLeft = 11;
            this.viewButton.IconPadding = 10;
            this.viewButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.viewButton.IdleBorderColor = System.Drawing.Color.White;
            this.viewButton.IdleBorderRadius = 3;
            this.viewButton.IdleBorderThickness = 1;
            this.viewButton.IdleFillColor = System.Drawing.Color.Black;
            this.viewButton.IdleIconLeftImage = null;
            this.viewButton.IdleIconRightImage = null;
            this.viewButton.IndicateFocus = false;
            this.viewButton.Location = new System.Drawing.Point(0, 411);
            this.viewButton.Name = "viewButton";
            this.viewButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.viewButton.onHoverState.BorderRadius = 3;
            this.viewButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.onHoverState.BorderThickness = 1;
            this.viewButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.viewButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.viewButton.onHoverState.IconLeftImage = null;
            this.viewButton.onHoverState.IconRightImage = null;
            this.viewButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.viewButton.OnIdleState.BorderRadius = 3;
            this.viewButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.OnIdleState.BorderThickness = 1;
            this.viewButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.viewButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.viewButton.OnIdleState.IconLeftImage = null;
            this.viewButton.OnIdleState.IconRightImage = null;
            this.viewButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.viewButton.OnPressedState.BorderRadius = 3;
            this.viewButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.OnPressedState.BorderThickness = 1;
            this.viewButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.viewButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.viewButton.OnPressedState.IconLeftImage = null;
            this.viewButton.OnPressedState.IconRightImage = null;
            this.viewButton.Size = new System.Drawing.Size(284, 57);
            this.viewButton.TabIndex = 5;
            this.viewButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.viewButton.TextMarginLeft = 0;
            this.viewButton.UseDefaultRadiusAndThickness = true;
            this.viewButton.Click += new System.EventHandler(this.viewButton_Click);
            // 
            // reportButton
            // 
            this.reportButton.AllowToggling = false;
            this.reportButton.AnimationSpeed = 200;
            this.reportButton.AutoGenerateColors = false;
            this.reportButton.BackColor = System.Drawing.Color.Transparent;
            this.reportButton.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.reportButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("reportButton.BackgroundImage")));
            this.reportButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.ButtonText = "Генерация отчетов";
            this.reportButton.ButtonTextMarginLeft = 0;
            this.reportButton.ColorContrastOnClick = 45;
            this.reportButton.ColorContrastOnHover = 45;
            this.reportButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges27.BottomLeft = true;
            borderEdges27.BottomRight = true;
            borderEdges27.TopLeft = true;
            borderEdges27.TopRight = true;
            this.reportButton.CustomizableEdges = borderEdges27;
            this.reportButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.reportButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.reportButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.reportButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.reportButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.reportButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.reportButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.reportButton.ForeColor = System.Drawing.Color.White;
            this.reportButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.reportButton.IconMarginLeft = 11;
            this.reportButton.IconPadding = 10;
            this.reportButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.reportButton.IdleBorderColor = System.Drawing.Color.White;
            this.reportButton.IdleBorderRadius = 3;
            this.reportButton.IdleBorderThickness = 1;
            this.reportButton.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.reportButton.IdleIconLeftImage = null;
            this.reportButton.IdleIconRightImage = null;
            this.reportButton.IndicateFocus = false;
            this.reportButton.Location = new System.Drawing.Point(0, 468);
            this.reportButton.Name = "reportButton";
            this.reportButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.reportButton.onHoverState.BorderRadius = 3;
            this.reportButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.onHoverState.BorderThickness = 1;
            this.reportButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.reportButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.reportButton.onHoverState.IconLeftImage = null;
            this.reportButton.onHoverState.IconRightImage = null;
            this.reportButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.reportButton.OnIdleState.BorderRadius = 3;
            this.reportButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.OnIdleState.BorderThickness = 1;
            this.reportButton.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.reportButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.reportButton.OnIdleState.IconLeftImage = null;
            this.reportButton.OnIdleState.IconRightImage = null;
            this.reportButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.reportButton.OnPressedState.BorderRadius = 3;
            this.reportButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.OnPressedState.BorderThickness = 1;
            this.reportButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.reportButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.reportButton.OnPressedState.IconLeftImage = null;
            this.reportButton.OnPressedState.IconRightImage = null;
            this.reportButton.Size = new System.Drawing.Size(284, 57);
            this.reportButton.TabIndex = 4;
            this.reportButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.reportButton.TextMarginLeft = 0;
            this.reportButton.UseDefaultRadiusAndThickness = true;
            this.reportButton.Click += new System.EventHandler(this.reportButton_Click);
            // 
            // logoPanel
            // 
            this.logoPanel.BackColor = System.Drawing.Color.SandyBrown;
            this.logoPanel.Controls.Add(this.label1);
            this.logoPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.logoPanel.Location = new System.Drawing.Point(0, 0);
            this.logoPanel.Name = "logoPanel";
            this.logoPanel.Size = new System.Drawing.Size(284, 420);
            this.logoPanel.TabIndex = 2;
            this.logoPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.logoPanel_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(35, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Футбольная Лига";
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.Color.White;
            this.headerPanel.Controls.Add(this.pictureBox1);
            this.headerPanel.Controls.Add(this.label4);
            this.headerPanel.Controls.Add(this.label3);
            this.headerPanel.Controls.Add(this.label2);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(284, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(718, 114);
            this.headerPanel.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(95, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 32);
            this.label4.TabIndex = 5;
            this.label4.Text = "Администратор";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(618, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "-";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(650, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 15;
            this.bunifuElipse1.TargetControl = this;
            // 
            // content
            // 
            this.content.BackColor = System.Drawing.Color.White;
            this.content.BorderRadius = 5;
            this.content.BottomSahddow = true;
            this.content.color = System.Drawing.Color.Tomato;
            this.content.Controls.Add(this.clubButton);
            this.content.Controls.Add(this.serviceTextBox);
            this.content.Controls.Add(this.label7);
            this.content.Controls.Add(this.nameTextBox);
            this.content.Controls.Add(this.label6);
            this.content.Controls.Add(this.idTextBox);
            this.content.Controls.Add(this.label5);
            this.content.Controls.Add(this.dataGridView1);
            this.content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.content.LeftSahddow = false;
            this.content.Location = new System.Drawing.Point(0, 0);
            this.content.Name = "content";
            this.content.RightSahddow = true;
            this.content.ShadowDepth = 20;
            this.content.Size = new System.Drawing.Size(718, 411);
            this.content.TabIndex = 0;
            // 
            // clubButton
            // 
            this.clubButton.AllowToggling = false;
            this.clubButton.AnimationSpeed = 200;
            this.clubButton.AutoGenerateColors = false;
            this.clubButton.BackColor = System.Drawing.Color.Transparent;
            this.clubButton.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.clubButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clubButton.BackgroundImage")));
            this.clubButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.clubButton.ButtonText = "Поиск";
            this.clubButton.ButtonTextMarginLeft = 0;
            this.clubButton.ColorContrastOnClick = 45;
            this.clubButton.ColorContrastOnHover = 45;
            this.clubButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges28.BottomLeft = true;
            borderEdges28.BottomRight = true;
            borderEdges28.TopLeft = true;
            borderEdges28.TopRight = true;
            this.clubButton.CustomizableEdges = borderEdges28;
            this.clubButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.clubButton.DisabledBorderColor = System.Drawing.Color.Empty;
            this.clubButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.clubButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.clubButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.clubButton.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.clubButton.ForeColor = System.Drawing.Color.White;
            this.clubButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.clubButton.IconMarginLeft = 11;
            this.clubButton.IconPadding = 10;
            this.clubButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.clubButton.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.clubButton.IdleBorderRadius = 3;
            this.clubButton.IdleBorderThickness = 1;
            this.clubButton.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.clubButton.IdleIconLeftImage = null;
            this.clubButton.IdleIconRightImage = null;
            this.clubButton.IndicateFocus = false;
            this.clubButton.Location = new System.Drawing.Point(483, 183);
            this.clubButton.Name = "clubButton";
            this.clubButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.clubButton.onHoverState.BorderRadius = 3;
            this.clubButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.clubButton.onHoverState.BorderThickness = 1;
            this.clubButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.clubButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.clubButton.onHoverState.IconLeftImage = null;
            this.clubButton.onHoverState.IconRightImage = null;
            this.clubButton.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.clubButton.OnIdleState.BorderRadius = 3;
            this.clubButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.clubButton.OnIdleState.BorderThickness = 1;
            this.clubButton.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.clubButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.clubButton.OnIdleState.IconLeftImage = null;
            this.clubButton.OnIdleState.IconRightImage = null;
            this.clubButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.clubButton.OnPressedState.BorderRadius = 3;
            this.clubButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.clubButton.OnPressedState.BorderThickness = 1;
            this.clubButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.clubButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.clubButton.OnPressedState.IconLeftImage = null;
            this.clubButton.OnPressedState.IconRightImage = null;
            this.clubButton.Size = new System.Drawing.Size(203, 82);
            this.clubButton.TabIndex = 41;
            this.clubButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.clubButton.TextMarginLeft = 0;
            this.clubButton.UseDefaultRadiusAndThickness = true;
            this.clubButton.Click += new System.EventHandler(this.clubButton_Click);
            // 
            // serviceTextBox
            // 
            this.serviceTextBox.BorderColor = System.Drawing.Color.SeaGreen;
            this.serviceTextBox.Location = new System.Drawing.Point(586, 123);
            this.serviceTextBox.Name = "serviceTextBox";
            this.serviceTextBox.Size = new System.Drawing.Size(100, 20);
            this.serviceTextBox.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(386, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(194, 32);
            this.label7.TabIndex = 11;
            this.label7.Text = "Название Сервиса:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.BorderColor = System.Drawing.Color.SeaGreen;
            this.nameTextBox.Location = new System.Drawing.Point(586, 72);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(386, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(194, 32);
            this.label6.TabIndex = 9;
            this.label6.Text = "Название Компании:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // idTextBox
            // 
            this.idTextBox.BorderColor = System.Drawing.Color.SeaGreen;
            this.idTextBox.Location = new System.Drawing.Point(586, 31);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(100, 20);
            this.idTextBox.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(386, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 32);
            this.label5.TabIndex = 7;
            this.label5.Text = "ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.name,
            this.service});
            this.dataGridView1.Location = new System.Drawing.Point(6, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(345, 186);
            this.dataGridView1.TabIndex = 1;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID Спонсора";
            this.ID.Name = "ID";
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "Название Компании";
            this.name.Name = "name";
            // 
            // service
            // 
            this.service.DataPropertyName = "service";
            this.service.HeaderText = "Название Сервиса";
            this.service.Name = "service";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.content);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(284, 114);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(718, 411);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.headerPanel;
            this.bunifuDragControl1.Vertical = true;
            // 
            // NewSS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1002, 525);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.sidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "NewSS";
            this.Text = "LogIn";
            this.Load += new System.EventHandler(this.NewMod_Load);
            this.sidePanel.ResumeLayout(false);
            this.logoPanel.ResumeLayout(false);
            this.logoPanel.PerformLayout();
            this.headerPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.content.ResumeLayout(false);
            this.content.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stadiumsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.footballLeagueDataSetBindingSource)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidePanel;
        private System.Windows.Forms.Panel logoPanel;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton complQuerryButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton plSearchButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton spSearchButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton viewButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton reportButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton modificationButton;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuCards content;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.BindingSource footballLeagueDataSetBindingSource;

        private System.Windows.Forms.BindingSource stadiumsBindingSource;

        private System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.BunifuCustomTextbox serviceTextBox;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.BunifuCustomTextbox nameTextBox;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.BunifuCustomTextbox idTextBox;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton clubButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn service;
    }
}