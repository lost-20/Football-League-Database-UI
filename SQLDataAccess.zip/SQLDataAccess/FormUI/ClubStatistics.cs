﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class ClubStatistics
    {
        public int rank { get; set; }
        public int Club_ID { get; set; }
        public int number_of_wins { get; set; }
        public int number_of_lesions { get; set; }
        public int draw_number { get; set; }
    }
}