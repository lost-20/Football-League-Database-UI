﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Sponsors
    {
        public int ID { get; set; }
        public string name { get; set; }
        public string service { get; set; }
    }
}
