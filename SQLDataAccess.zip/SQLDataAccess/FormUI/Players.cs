﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Players
    {
        public int ID { get; set; }
        public int Club_ID { get; set; }
        public string name { get; set; }
        public int age { get; set; }
        public string nationality { get; set; }
        public int wage { get; set; }
        public string position_in_team { get; set; }
        public int number_in_team { get; set; }
        public int height { get; set; }
        public int weight { get; set; }
    }
}