﻿namespace FormUI
{
    partial class NewComplUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewComplUser));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.sidePanel = new System.Windows.Forms.Panel();
            this.modificationButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.complQuerryButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.plSearchButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.spSearchButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.viewButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.reportButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.logoPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.content = new Bunifu.Framework.UI.BunifuCards();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clubs_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nationality = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wages = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.height = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.trID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cl_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.app = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.rank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.club_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.num_of_wins = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.number_of_lesions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.draw_num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searchButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.nameTextBox = new Bunifu.Framework.BunifuCustomTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtstaduim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.sidePanel.SuspendLayout();
            this.logoPanel.SuspendLayout();
            this.headerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.content.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidePanel
            // 
            this.sidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sidePanel.Controls.Add(this.modificationButton);
            this.sidePanel.Controls.Add(this.complQuerryButton);
            this.sidePanel.Controls.Add(this.plSearchButton);
            this.sidePanel.Controls.Add(this.spSearchButton);
            this.sidePanel.Controls.Add(this.viewButton);
            this.sidePanel.Controls.Add(this.reportButton);
            this.sidePanel.Controls.Add(this.logoPanel);
            this.sidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidePanel.Location = new System.Drawing.Point(0, 0);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(284, 774);
            this.sidePanel.TabIndex = 0;
            this.sidePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.sidePanel_Paint);
            // 
            // modificationButton
            // 
            this.modificationButton.AllowToggling = false;
            this.modificationButton.AnimationSpeed = 200;
            this.modificationButton.AutoGenerateColors = false;
            this.modificationButton.BackColor = System.Drawing.Color.Transparent;
            this.modificationButton.BackColor1 = System.Drawing.Color.Black;
            this.modificationButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("modificationButton.BackgroundImage")));
            this.modificationButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.ButtonText = "Модификация базы данных (Нет прав)";
            this.modificationButton.ButtonTextMarginLeft = 0;
            this.modificationButton.ColorContrastOnClick = 45;
            this.modificationButton.ColorContrastOnHover = 45;
            this.modificationButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges8.BottomLeft = true;
            borderEdges8.BottomRight = true;
            borderEdges8.TopLeft = true;
            borderEdges8.TopRight = true;
            this.modificationButton.CustomizableEdges = borderEdges8;
            this.modificationButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.modificationButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.modificationButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.modificationButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.modificationButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.modificationButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.modificationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.modificationButton.ForeColor = System.Drawing.Color.White;
            this.modificationButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.modificationButton.IconMarginLeft = 11;
            this.modificationButton.IconPadding = 10;
            this.modificationButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.modificationButton.IdleBorderColor = System.Drawing.Color.White;
            this.modificationButton.IdleBorderRadius = 3;
            this.modificationButton.IdleBorderThickness = 1;
            this.modificationButton.IdleFillColor = System.Drawing.Color.Black;
            this.modificationButton.IdleIconLeftImage = null;
            this.modificationButton.IdleIconRightImage = null;
            this.modificationButton.IndicateFocus = false;
            this.modificationButton.Location = new System.Drawing.Point(0, 432);
            this.modificationButton.Name = "modificationButton";
            this.modificationButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.modificationButton.onHoverState.BorderRadius = 3;
            this.modificationButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.onHoverState.BorderThickness = 1;
            this.modificationButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.modificationButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.modificationButton.onHoverState.IconLeftImage = null;
            this.modificationButton.onHoverState.IconRightImage = null;
            this.modificationButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.modificationButton.OnIdleState.BorderRadius = 3;
            this.modificationButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.OnIdleState.BorderThickness = 1;
            this.modificationButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.modificationButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.modificationButton.OnIdleState.IconLeftImage = null;
            this.modificationButton.OnIdleState.IconRightImage = null;
            this.modificationButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.modificationButton.OnPressedState.BorderRadius = 3;
            this.modificationButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.modificationButton.OnPressedState.BorderThickness = 1;
            this.modificationButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.modificationButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.modificationButton.OnPressedState.IconLeftImage = null;
            this.modificationButton.OnPressedState.IconRightImage = null;
            this.modificationButton.Size = new System.Drawing.Size(284, 57);
            this.modificationButton.TabIndex = 9;
            this.modificationButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.modificationButton.TextMarginLeft = 0;
            this.modificationButton.UseDefaultRadiusAndThickness = true;
            // 
            // complQuerryButton
            // 
            this.complQuerryButton.AllowToggling = false;
            this.complQuerryButton.AnimationSpeed = 200;
            this.complQuerryButton.AutoGenerateColors = false;
            this.complQuerryButton.BackColor = System.Drawing.Color.Transparent;
            this.complQuerryButton.BackColor1 = System.Drawing.Color.Black;
            this.complQuerryButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("complQuerryButton.BackgroundImage")));
            this.complQuerryButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.ButtonText = "Сложные запросы к базе данных";
            this.complQuerryButton.ButtonTextMarginLeft = 0;
            this.complQuerryButton.ColorContrastOnClick = 45;
            this.complQuerryButton.ColorContrastOnHover = 45;
            this.complQuerryButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges9.BottomLeft = true;
            borderEdges9.BottomRight = true;
            borderEdges9.TopLeft = true;
            borderEdges9.TopRight = true;
            this.complQuerryButton.CustomizableEdges = borderEdges9;
            this.complQuerryButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.complQuerryButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.complQuerryButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.complQuerryButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.complQuerryButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.complQuerryButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.complQuerryButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.complQuerryButton.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.complQuerryButton.IconMarginLeft = 11;
            this.complQuerryButton.IconPadding = 10;
            this.complQuerryButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.complQuerryButton.IdleBorderColor = System.Drawing.Color.White;
            this.complQuerryButton.IdleBorderRadius = 3;
            this.complQuerryButton.IdleBorderThickness = 1;
            this.complQuerryButton.IdleFillColor = System.Drawing.Color.Black;
            this.complQuerryButton.IdleIconLeftImage = null;
            this.complQuerryButton.IdleIconRightImage = null;
            this.complQuerryButton.IndicateFocus = false;
            this.complQuerryButton.Location = new System.Drawing.Point(0, 489);
            this.complQuerryButton.Name = "complQuerryButton";
            this.complQuerryButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.complQuerryButton.onHoverState.BorderRadius = 3;
            this.complQuerryButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.onHoverState.BorderThickness = 1;
            this.complQuerryButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.complQuerryButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.onHoverState.IconLeftImage = null;
            this.complQuerryButton.onHoverState.IconRightImage = null;
            this.complQuerryButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.complQuerryButton.OnIdleState.BorderRadius = 3;
            this.complQuerryButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.OnIdleState.BorderThickness = 1;
            this.complQuerryButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.complQuerryButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.OnIdleState.IconLeftImage = null;
            this.complQuerryButton.OnIdleState.IconRightImage = null;
            this.complQuerryButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.complQuerryButton.OnPressedState.BorderRadius = 3;
            this.complQuerryButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.complQuerryButton.OnPressedState.BorderThickness = 1;
            this.complQuerryButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.complQuerryButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.complQuerryButton.OnPressedState.IconLeftImage = null;
            this.complQuerryButton.OnPressedState.IconRightImage = null;
            this.complQuerryButton.Size = new System.Drawing.Size(284, 57);
            this.complQuerryButton.TabIndex = 8;
            this.complQuerryButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.complQuerryButton.TextMarginLeft = 0;
            this.complQuerryButton.UseDefaultRadiusAndThickness = true;
            this.complQuerryButton.Click += new System.EventHandler(this.complQuerryButton_Click);
            // 
            // plSearchButton
            // 
            this.plSearchButton.AllowToggling = false;
            this.plSearchButton.AnimationSpeed = 200;
            this.plSearchButton.AutoGenerateColors = false;
            this.plSearchButton.BackColor = System.Drawing.Color.Transparent;
            this.plSearchButton.BackColor1 = System.Drawing.Color.Black;
            this.plSearchButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plSearchButton.BackgroundImage")));
            this.plSearchButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.ButtonText = "Поиск игроков";
            this.plSearchButton.ButtonTextMarginLeft = 0;
            this.plSearchButton.ColorContrastOnClick = 45;
            this.plSearchButton.ColorContrastOnHover = 45;
            this.plSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.plSearchButton.CustomizableEdges = borderEdges10;
            this.plSearchButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.plSearchButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.plSearchButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.plSearchButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.plSearchButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.plSearchButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.plSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.plSearchButton.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.plSearchButton.IconMarginLeft = 11;
            this.plSearchButton.IconPadding = 10;
            this.plSearchButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.plSearchButton.IdleBorderColor = System.Drawing.Color.White;
            this.plSearchButton.IdleBorderRadius = 3;
            this.plSearchButton.IdleBorderThickness = 1;
            this.plSearchButton.IdleFillColor = System.Drawing.Color.Black;
            this.plSearchButton.IdleIconLeftImage = null;
            this.plSearchButton.IdleIconRightImage = null;
            this.plSearchButton.IndicateFocus = false;
            this.plSearchButton.Location = new System.Drawing.Point(0, 546);
            this.plSearchButton.Name = "plSearchButton";
            this.plSearchButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.plSearchButton.onHoverState.BorderRadius = 3;
            this.plSearchButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.onHoverState.BorderThickness = 1;
            this.plSearchButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.plSearchButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.onHoverState.IconLeftImage = null;
            this.plSearchButton.onHoverState.IconRightImage = null;
            this.plSearchButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.plSearchButton.OnIdleState.BorderRadius = 3;
            this.plSearchButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.OnIdleState.BorderThickness = 1;
            this.plSearchButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.plSearchButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.OnIdleState.IconLeftImage = null;
            this.plSearchButton.OnIdleState.IconRightImage = null;
            this.plSearchButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.plSearchButton.OnPressedState.BorderRadius = 3;
            this.plSearchButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.plSearchButton.OnPressedState.BorderThickness = 1;
            this.plSearchButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.plSearchButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.plSearchButton.OnPressedState.IconLeftImage = null;
            this.plSearchButton.OnPressedState.IconRightImage = null;
            this.plSearchButton.Size = new System.Drawing.Size(284, 57);
            this.plSearchButton.TabIndex = 7;
            this.plSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.plSearchButton.TextMarginLeft = 0;
            this.plSearchButton.UseDefaultRadiusAndThickness = true;
            this.plSearchButton.Click += new System.EventHandler(this.plSearchButton_Click);
            // 
            // spSearchButton
            // 
            this.spSearchButton.AllowToggling = false;
            this.spSearchButton.AnimationSpeed = 200;
            this.spSearchButton.AutoGenerateColors = false;
            this.spSearchButton.BackColor = System.Drawing.Color.Transparent;
            this.spSearchButton.BackColor1 = System.Drawing.Color.Black;
            this.spSearchButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("spSearchButton.BackgroundImage")));
            this.spSearchButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.ButtonText = "Поиск спонсоров";
            this.spSearchButton.ButtonTextMarginLeft = 0;
            this.spSearchButton.ColorContrastOnClick = 45;
            this.spSearchButton.ColorContrastOnHover = 45;
            this.spSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.spSearchButton.CustomizableEdges = borderEdges11;
            this.spSearchButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.spSearchButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.spSearchButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.spSearchButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.spSearchButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.spSearchButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.spSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.spSearchButton.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.spSearchButton.IconMarginLeft = 11;
            this.spSearchButton.IconPadding = 10;
            this.spSearchButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.spSearchButton.IdleBorderColor = System.Drawing.Color.White;
            this.spSearchButton.IdleBorderRadius = 3;
            this.spSearchButton.IdleBorderThickness = 1;
            this.spSearchButton.IdleFillColor = System.Drawing.Color.Black;
            this.spSearchButton.IdleIconLeftImage = null;
            this.spSearchButton.IdleIconRightImage = null;
            this.spSearchButton.IndicateFocus = false;
            this.spSearchButton.Location = new System.Drawing.Point(0, 603);
            this.spSearchButton.Name = "spSearchButton";
            this.spSearchButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.spSearchButton.onHoverState.BorderRadius = 3;
            this.spSearchButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.onHoverState.BorderThickness = 1;
            this.spSearchButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.spSearchButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.onHoverState.IconLeftImage = null;
            this.spSearchButton.onHoverState.IconRightImage = null;
            this.spSearchButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.spSearchButton.OnIdleState.BorderRadius = 3;
            this.spSearchButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.OnIdleState.BorderThickness = 1;
            this.spSearchButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.spSearchButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.OnIdleState.IconLeftImage = null;
            this.spSearchButton.OnIdleState.IconRightImage = null;
            this.spSearchButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.spSearchButton.OnPressedState.BorderRadius = 3;
            this.spSearchButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.spSearchButton.OnPressedState.BorderThickness = 1;
            this.spSearchButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.spSearchButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.spSearchButton.OnPressedState.IconLeftImage = null;
            this.spSearchButton.OnPressedState.IconRightImage = null;
            this.spSearchButton.Size = new System.Drawing.Size(284, 57);
            this.spSearchButton.TabIndex = 6;
            this.spSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.spSearchButton.TextMarginLeft = 0;
            this.spSearchButton.UseDefaultRadiusAndThickness = true;
            this.spSearchButton.Click += new System.EventHandler(this.spSearchButton_Click);
            // 
            // viewButton
            // 
            this.viewButton.AllowToggling = false;
            this.viewButton.AnimationSpeed = 200;
            this.viewButton.AutoGenerateColors = false;
            this.viewButton.BackColor = System.Drawing.Color.Transparent;
            this.viewButton.BackColor1 = System.Drawing.Color.Black;
            this.viewButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("viewButton.BackgroundImage")));
            this.viewButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.ButtonText = "Вставка в представление игроков и тренеров";
            this.viewButton.ButtonTextMarginLeft = 0;
            this.viewButton.ColorContrastOnClick = 45;
            this.viewButton.ColorContrastOnHover = 45;
            this.viewButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.viewButton.CustomizableEdges = borderEdges12;
            this.viewButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.viewButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.viewButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.viewButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.viewButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.viewButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.viewButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.viewButton.ForeColor = System.Drawing.Color.White;
            this.viewButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.viewButton.IconMarginLeft = 11;
            this.viewButton.IconPadding = 10;
            this.viewButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.viewButton.IdleBorderColor = System.Drawing.Color.White;
            this.viewButton.IdleBorderRadius = 3;
            this.viewButton.IdleBorderThickness = 1;
            this.viewButton.IdleFillColor = System.Drawing.Color.Black;
            this.viewButton.IdleIconLeftImage = null;
            this.viewButton.IdleIconRightImage = null;
            this.viewButton.IndicateFocus = false;
            this.viewButton.Location = new System.Drawing.Point(0, 660);
            this.viewButton.Name = "viewButton";
            this.viewButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.viewButton.onHoverState.BorderRadius = 3;
            this.viewButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.onHoverState.BorderThickness = 1;
            this.viewButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.viewButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.viewButton.onHoverState.IconLeftImage = null;
            this.viewButton.onHoverState.IconRightImage = null;
            this.viewButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.viewButton.OnIdleState.BorderRadius = 3;
            this.viewButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.OnIdleState.BorderThickness = 1;
            this.viewButton.OnIdleState.FillColor = System.Drawing.Color.Black;
            this.viewButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.viewButton.OnIdleState.IconLeftImage = null;
            this.viewButton.OnIdleState.IconRightImage = null;
            this.viewButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.viewButton.OnPressedState.BorderRadius = 3;
            this.viewButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.viewButton.OnPressedState.BorderThickness = 1;
            this.viewButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.viewButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.viewButton.OnPressedState.IconLeftImage = null;
            this.viewButton.OnPressedState.IconRightImage = null;
            this.viewButton.Size = new System.Drawing.Size(284, 57);
            this.viewButton.TabIndex = 5;
            this.viewButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.viewButton.TextMarginLeft = 0;
            this.viewButton.UseDefaultRadiusAndThickness = true;
            this.viewButton.Click += new System.EventHandler(this.viewButton_Click);
            // 
            // reportButton
            // 
            this.reportButton.AllowToggling = false;
            this.reportButton.AnimationSpeed = 200;
            this.reportButton.AutoGenerateColors = false;
            this.reportButton.BackColor = System.Drawing.Color.Transparent;
            this.reportButton.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.reportButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("reportButton.BackgroundImage")));
            this.reportButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.ButtonText = "Генерация отчетов";
            this.reportButton.ButtonTextMarginLeft = 0;
            this.reportButton.ColorContrastOnClick = 45;
            this.reportButton.ColorContrastOnHover = 45;
            this.reportButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges13.BottomLeft = true;
            borderEdges13.BottomRight = true;
            borderEdges13.TopLeft = true;
            borderEdges13.TopRight = true;
            this.reportButton.CustomizableEdges = borderEdges13;
            this.reportButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.reportButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.reportButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.reportButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.reportButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.reportButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Disabled;
            this.reportButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.reportButton.ForeColor = System.Drawing.Color.White;
            this.reportButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.reportButton.IconMarginLeft = 11;
            this.reportButton.IconPadding = 10;
            this.reportButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.reportButton.IdleBorderColor = System.Drawing.Color.White;
            this.reportButton.IdleBorderRadius = 3;
            this.reportButton.IdleBorderThickness = 1;
            this.reportButton.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.reportButton.IdleIconLeftImage = null;
            this.reportButton.IdleIconRightImage = null;
            this.reportButton.IndicateFocus = false;
            this.reportButton.Location = new System.Drawing.Point(0, 717);
            this.reportButton.Name = "reportButton";
            this.reportButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.reportButton.onHoverState.BorderRadius = 3;
            this.reportButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.onHoverState.BorderThickness = 1;
            this.reportButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.reportButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.reportButton.onHoverState.IconLeftImage = null;
            this.reportButton.onHoverState.IconRightImage = null;
            this.reportButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.reportButton.OnIdleState.BorderRadius = 3;
            this.reportButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.OnIdleState.BorderThickness = 1;
            this.reportButton.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.reportButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.reportButton.OnIdleState.IconLeftImage = null;
            this.reportButton.OnIdleState.IconRightImage = null;
            this.reportButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.reportButton.OnPressedState.BorderRadius = 3;
            this.reportButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.reportButton.OnPressedState.BorderThickness = 1;
            this.reportButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.reportButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.reportButton.OnPressedState.IconLeftImage = null;
            this.reportButton.OnPressedState.IconRightImage = null;
            this.reportButton.Size = new System.Drawing.Size(284, 57);
            this.reportButton.TabIndex = 4;
            this.reportButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.reportButton.TextMarginLeft = 0;
            this.reportButton.UseDefaultRadiusAndThickness = true;
            this.reportButton.Click += new System.EventHandler(this.reportButton_Click);
            // 
            // logoPanel
            // 
            this.logoPanel.BackColor = System.Drawing.Color.SandyBrown;
            this.logoPanel.Controls.Add(this.label1);
            this.logoPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.logoPanel.Location = new System.Drawing.Point(0, 0);
            this.logoPanel.Name = "logoPanel";
            this.logoPanel.Size = new System.Drawing.Size(284, 435);
            this.logoPanel.TabIndex = 2;
            this.logoPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.logoPanel_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(35, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Футбольная Лига";
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.Color.White;
            this.headerPanel.Controls.Add(this.label12);
            this.headerPanel.Controls.Add(this.label13);
            this.headerPanel.Controls.Add(this.pictureBox1);
            this.headerPanel.Controls.Add(this.label4);
            this.headerPanel.Controls.Add(this.label3);
            this.headerPanel.Controls.Add(this.label2);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(284, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(1016, 114);
            this.headerPanel.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(948, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 32);
            this.label12.TabIndex = 10;
            this.label12.Text = "-";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(980, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 32);
            this.label13.TabIndex = 9;
            this.label13.Text = "X";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(95, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 32);
            this.label4.TabIndex = 5;
            this.label4.Text = "Пользователь";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(1059, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "-";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(1091, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 15;
            this.bunifuElipse1.TargetControl = this;
            // 
            // content
            // 
            this.content.BackColor = System.Drawing.Color.White;
            this.content.BorderRadius = 5;
            this.content.BottomSahddow = true;
            this.content.color = System.Drawing.Color.Tomato;
            this.content.Controls.Add(this.label9);
            this.content.Controls.Add(this.label8);
            this.content.Controls.Add(this.label7);
            this.content.Controls.Add(this.label6);
            this.content.Controls.Add(this.dataGridView4);
            this.content.Controls.Add(this.dataGridView3);
            this.content.Controls.Add(this.dataGridView2);
            this.content.Controls.Add(this.searchButton);
            this.content.Controls.Add(this.nameTextBox);
            this.content.Controls.Add(this.label5);
            this.content.Controls.Add(this.dataGridView1);
            this.content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.content.LeftSahddow = false;
            this.content.Location = new System.Drawing.Point(0, 0);
            this.content.Name = "content";
            this.content.RightSahddow = true;
            this.content.ShadowDepth = 20;
            this.content.Size = new System.Drawing.Size(1016, 660);
            this.content.TabIndex = 0;
            this.content.Paint += new System.Windows.Forms.PaintEventHandler(this.content_Paint_1);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(39, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 32);
            this.label9.TabIndex = 15;
            this.label9.Text = "Игроки:";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(95, 259);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 32);
            this.label8.TabIndex = 14;
            this.label8.Text = "Тренеры:";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(346, 149);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 32);
            this.label7.TabIndex = 13;
            this.label7.Text = "Статистика:";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(401, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 32);
            this.label6.TabIndex = 12;
            this.label6.Text = "Клубы:";
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.clubs_ID,
            this.fullname,
            this.age,
            this.nationality,
            this.wages,
            this.position,
            this.number,
            this.height,
            this.weight});
            this.dataGridView4.Location = new System.Drawing.Point(-4, 370);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1050, 287);
            this.dataGridView4.TabIndex = 11;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            // 
            // clubs_ID
            // 
            this.clubs_ID.DataPropertyName = "Club_ID";
            this.clubs_ID.HeaderText = "ID Клуба";
            this.clubs_ID.Name = "clubs_ID";
            // 
            // fullname
            // 
            this.fullname.DataPropertyName = "name";
            this.fullname.HeaderText = "Имя";
            this.fullname.Name = "fullname";
            // 
            // age
            // 
            this.age.DataPropertyName = "age";
            this.age.HeaderText = "Возраст";
            this.age.Name = "age";
            // 
            // nationality
            // 
            this.nationality.DataPropertyName = "nationality";
            this.nationality.HeaderText = "Национальность";
            this.nationality.Name = "nationality";
            // 
            // wages
            // 
            this.wages.DataPropertyName = "wage";
            this.wages.HeaderText = "Зарплата";
            this.wages.Name = "wages";
            // 
            // position
            // 
            this.position.DataPropertyName = "position_in_team";
            this.position.HeaderText = "Позиция В Команде";
            this.position.Name = "position";
            // 
            // number
            // 
            this.number.DataPropertyName = "number_in_team";
            this.number.HeaderText = "Номер В Команде ";
            this.number.Name = "number";
            // 
            // height
            // 
            this.height.DataPropertyName = "height";
            this.height.HeaderText = "Высота";
            this.height.Name = "height";
            // 
            // weight
            // 
            this.weight.DataPropertyName = "weight";
            this.weight.HeaderText = "Вес";
            this.weight.Name = "weight";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.trID,
            this.cl_ID,
            this.name,
            this.birth,
            this.pos,
            this.wage,
            this.app,
            this.dis});
            this.dataGridView3.Location = new System.Drawing.Point(211, 209);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(835, 133);
            this.dataGridView3.TabIndex = 10;
            // 
            // trID
            // 
            this.trID.DataPropertyName = "ID";
            this.trID.HeaderText = "ID Тренера";
            this.trID.Name = "trID";
            // 
            // cl_ID
            // 
            this.cl_ID.DataPropertyName = "Club_ID";
            this.cl_ID.HeaderText = "ID Клуба";
            this.cl_ID.Name = "cl_ID";
            // 
            // name
            // 
            this.name.DataPropertyName = "full_name";
            this.name.HeaderText = "Имя ";
            this.name.Name = "name";
            // 
            // birth
            // 
            this.birth.DataPropertyName = "date_of_birth";
            this.birth.HeaderText = "Дата Рождения";
            this.birth.Name = "birth";
            // 
            // pos
            // 
            this.pos.DataPropertyName = "position";
            this.pos.HeaderText = "Позиция";
            this.pos.Name = "pos";
            // 
            // wage
            // 
            this.wage.DataPropertyName = "wage";
            this.wage.HeaderText = "Зарплата";
            this.wage.Name = "wage";
            // 
            // app
            // 
            this.app.DataPropertyName = "date_of_appointment";
            this.app.HeaderText = "Дата Вступления В Должность";
            this.app.Name = "app";
            // 
            // dis
            // 
            this.dis.DataPropertyName = "dismissal_date";
            this.dis.HeaderText = "Дата Увольнения";
            this.dis.Name = "dis";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rank,
            this.club_id,
            this.num_of_wins,
            this.number_of_lesions,
            this.draw_num});
            this.dataGridView2.Location = new System.Drawing.Point(503, 136);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(543, 58);
            this.dataGridView2.TabIndex = 9;
            // 
            // rank
            // 
            this.rank.DataPropertyName = "rank";
            this.rank.HeaderText = "Ранг";
            this.rank.Name = "rank";
            // 
            // club_id
            // 
            this.club_id.DataPropertyName = "Club_ID";
            this.club_id.HeaderText = "ID Клуба";
            this.club_id.Name = "club_id";
            // 
            // num_of_wins
            // 
            this.num_of_wins.DataPropertyName = "number_of_wins";
            this.num_of_wins.HeaderText = "Число Побед";
            this.num_of_wins.Name = "num_of_wins";
            // 
            // number_of_lesions
            // 
            this.number_of_lesions.DataPropertyName = "number_of_lesions";
            this.number_of_lesions.HeaderText = "Число Поражений";
            this.number_of_lesions.Name = "number_of_lesions";
            // 
            // draw_num
            // 
            this.draw_num.DataPropertyName = "draw_number";
            this.draw_num.HeaderText = "Число Ничьих";
            this.draw_num.Name = "draw_num";
            // 
            // searchButton
            // 
            this.searchButton.AllowToggling = false;
            this.searchButton.AnimationSpeed = 200;
            this.searchButton.AutoGenerateColors = false;
            this.searchButton.BackColor = System.Drawing.Color.Transparent;
            this.searchButton.BackColor1 = System.Drawing.Color.OliveDrab;
            this.searchButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("searchButton.BackgroundImage")));
            this.searchButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.searchButton.ButtonText = "Поиск";
            this.searchButton.ButtonTextMarginLeft = 0;
            this.searchButton.ColorContrastOnClick = 45;
            this.searchButton.ColorContrastOnHover = 45;
            this.searchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges14.BottomLeft = true;
            borderEdges14.BottomRight = true;
            borderEdges14.TopLeft = true;
            borderEdges14.TopRight = true;
            this.searchButton.CustomizableEdges = borderEdges14;
            this.searchButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.searchButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.searchButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.searchButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.searchButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.searchButton.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.searchButton.ForeColor = System.Drawing.Color.White;
            this.searchButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.searchButton.IconMarginLeft = 11;
            this.searchButton.IconPadding = 10;
            this.searchButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.searchButton.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.searchButton.IdleBorderRadius = 3;
            this.searchButton.IdleBorderThickness = 1;
            this.searchButton.IdleFillColor = System.Drawing.Color.OliveDrab;
            this.searchButton.IdleIconLeftImage = null;
            this.searchButton.IdleIconRightImage = null;
            this.searchButton.IndicateFocus = false;
            this.searchButton.Location = new System.Drawing.Point(3, 149);
            this.searchButton.Name = "searchButton";
            this.searchButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.searchButton.onHoverState.BorderRadius = 3;
            this.searchButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.searchButton.onHoverState.BorderThickness = 1;
            this.searchButton.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.searchButton.onHoverState.ForeColor = System.Drawing.Color.White;
            this.searchButton.onHoverState.IconLeftImage = null;
            this.searchButton.onHoverState.IconRightImage = null;
            this.searchButton.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.searchButton.OnIdleState.BorderRadius = 3;
            this.searchButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.searchButton.OnIdleState.BorderThickness = 1;
            this.searchButton.OnIdleState.FillColor = System.Drawing.Color.OliveDrab;
            this.searchButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.searchButton.OnIdleState.IconLeftImage = null;
            this.searchButton.OnIdleState.IconRightImage = null;
            this.searchButton.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.searchButton.OnPressedState.BorderRadius = 3;
            this.searchButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.searchButton.OnPressedState.BorderThickness = 1;
            this.searchButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.searchButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.searchButton.OnPressedState.IconLeftImage = null;
            this.searchButton.OnPressedState.IconRightImage = null;
            this.searchButton.Size = new System.Drawing.Size(98, 45);
            this.searchButton.TabIndex = 8;
            this.searchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.searchButton.TextMarginLeft = 0;
            this.searchButton.UseDefaultRadiusAndThickness = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.BorderColor = System.Drawing.Color.SeaGreen;
            this.nameTextBox.Location = new System.Drawing.Point(3, 96);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(268, 20);
            this.nameTextBox.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(3, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(307, 32);
            this.label5.TabIndex = 6;
            this.label5.Text = "Введите название клуба";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txtID,
            this.txtdate,
            this.clname,
            this.txtname,
            this.txtstaduim});
            this.dataGridView1.Location = new System.Drawing.Point(503, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(543, 59);
            this.dataGridView1.TabIndex = 1;
            // 
            // txtID
            // 
            this.txtID.DataPropertyName = "ID";
            this.txtID.HeaderText = "ID";
            this.txtID.Name = "txtID";
            // 
            // txtdate
            // 
            this.txtdate.DataPropertyName = "date_of_establishment";
            this.txtdate.HeaderText = "Дата основания";
            this.txtdate.Name = "txtdate";
            // 
            // clname
            // 
            this.clname.DataPropertyName = "name";
            this.clname.HeaderText = "Название клуба";
            this.clname.Name = "clname";
            // 
            // txtname
            // 
            this.txtname.DataPropertyName = "Stadium_name";
            this.txtname.HeaderText = "Название Стадиона";
            this.txtname.Name = "txtname";
            // 
            // txtstaduim
            // 
            this.txtstaduim.DataPropertyName = "Stadium_ID";
            this.txtstaduim.HeaderText = "ID Стадиона";
            this.txtstaduim.Name = "txtstaduim";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.content);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(284, 114);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1016, 660);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.headerPanel;
            this.bunifuDragControl1.Vertical = true;
            // 
            // NewComplUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1300, 774);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.sidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "NewComplUser";
            this.Text = "LogIn";
            this.Load += new System.EventHandler(this.NewMod_Load);
            this.sidePanel.ResumeLayout(false);
            this.logoPanel.ResumeLayout(false);
            this.logoPanel.PerformLayout();
            this.headerPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.content.ResumeLayout(false);
            this.content.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidePanel;
        private System.Windows.Forms.Panel logoPanel;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton complQuerryButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton plSearchButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton spSearchButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton viewButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton reportButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton modificationButton;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuCards content;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.BunifuCustomTextbox nameTextBox;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton searchButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtID;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn clname;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtname;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtstaduim;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn rank;
        private System.Windows.Forms.DataGridViewTextBoxColumn club_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn num_of_wins;
        private System.Windows.Forms.DataGridViewTextBoxColumn number_of_lesions;
        private System.Windows.Forms.DataGridViewTextBoxColumn draw_num;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn trID;
        private System.Windows.Forms.DataGridViewTextBoxColumn cl_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn birth;
        private System.Windows.Forms.DataGridViewTextBoxColumn pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn wage;
        private System.Windows.Forms.DataGridViewTextBoxColumn app;
        private System.Windows.Forms.DataGridViewTextBoxColumn dis;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn clubs_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullname;
        private System.Windows.Forms.DataGridViewTextBoxColumn age;
        private System.Windows.Forms.DataGridViewTextBoxColumn nationality;
        private System.Windows.Forms.DataGridViewTextBoxColumn wages;
        private System.Windows.Forms.DataGridViewTextBoxColumn position;
        private System.Windows.Forms.DataGridViewTextBoxColumn number;
        private System.Windows.Forms.DataGridViewTextBoxColumn height;
        private System.Windows.Forms.DataGridViewTextBoxColumn weight;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}