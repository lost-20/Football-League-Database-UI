﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
 
        }

        private void logoPanel_Paint(object sender, PaintEventArgs e)
        {
            logoPanel.BackColor = Color.FromArgb(229, 126, 49);
        }

        private void sidePanel_Paint(object sender, PaintEventArgs e)
        {
            sidePanel.BackColor = Color.FromArgb(41, 53, 65);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn log = new LogIn();
            log.ShowDialog();
        }

        private void content_Paint(object sender, PaintEventArgs e)
        {
            content.color = Color.FromArgb(229, 126, 49);
        }

        private void signInButton_Click(object sender, EventArgs e)
        {
            if (logonTextBox.Text == "admin" && passwordTextBox.Text == "password")
            {
                Remembered.Value = true;
                this.Hide();
                NewMain main = new NewMain();
                main.ShowDialog();
                }
            if (logonTextBox.Text == "user" && passwordTextBox.Text == "password")
            {
                Remembered.Value = false;
                this.Hide();
                NewMainUser main = new NewMainUser();
                main.ShowDialog();
            }
        }
    }
}
