﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Reports
    {
        public string name { get; set; }
        public decimal pwage { get; set; }
        public string position_in_team { get; set; }
        public string full_name { get; set; }
        public string position { get; set; }
        public decimal wage { get; set; }
    }
}
